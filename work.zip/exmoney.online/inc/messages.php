<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
     include('functions.php'); 
     $mes_all= select_m($_GET['p']); 
     $text_page = $_GET['p'];
    $text_g = "��������";
     if($text_page=="1")
       {
       $text_g = "��������";
       }
       if($text_page=="2")
       {
       $text_g = "������������";
       }
       if($text_page=="3")
       {
       $text_g = "�����";
       }
include ('menu.php');
if(isset($_GET['del'])) 
{  
del_m($_GET['del']);
echo("<script>location.href='messages.php'</script>");
}
if(isset($_GET['arx'])) 
{  
arhiv_m($_GET['arx']);
echo("<script>location.href='messages.php'</script>");
}
if(isset($_GET['act'])) 
{  
activ_m($_GET['act']);
echo("<script>location.href='messages.php'</script>");
}

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/style_tb.css" type="text/css"  />
<style>
body 
{
font-family: Arial, Helvetica, sans-serif;
background-color: #FFFFF0;
background: 
radial-gradient(ellipse farthest-corner at right bottom, #fedb37 0%, #FDB931 8%, #9f7928 30%, #8a6e2f 40%, transparent 80%),
		radial-gradient(ellipse farthest-corner at left top, #ffffff 0%, #ffffac 8%, #d1b464 25%, #5d4a1f 62.5%, #5d4a1f 100%);
}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
}
textarea 
{ 
width: 100%; 
box-sizing: border-box; 
}

a {
    background-image: linear-gradient(lightgray, skygray);
    border: 1px solid #eee;
    border-radius: 3px;
    color: grey;
    display: inline-block;
    line-height: 32px;
    padding: 0 15px;
    text-decoration: none;
    transition: none;
    vertical-align: top;
}
a:hover {
  box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2;  
}
.button-grey {
    background-color: #f2f2f2;
    background-image: linear-gradient(to bottom, #f2f2f2, #f2f2f2);
    border: 1px solid #bfbfbf;
    box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #8c8c8c;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
    
}
.button-yellow {
    background-color: #fce374;
    background-image: linear-gradient(to bottom, #fce374, #fcdf5b);
    border: 1px solid #c9ae34;
    box-shadow: inset 0 1px 0 #fff6ce, inset 0 -1px 0 #e3c852, inset 0 0 0 1px #fce88d, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #967d09;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}
.button-orange {
    background-color: #f58a38;
    background-image: linear-gradient(to bottom, #f58a38, #f57c20);
    border: 1px solid #c25706;
    box-shadow: inset 0 1px 0 #ffb984, inset 0 -1px 0 #db6f1d, inset 0 0 0 1px #f59851, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-red {
    background-color: #ed6d64;
    background-image: linear-gradient(to bottom, #ed6d64, #ed574c);
    border: 1px solid #ba3329;
    box-shadow: inset 0 1px 0 #ffb0aa, inset 0 -1px 0 #d44d44, inset 0 0 0 1px #ed837b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-purple {
    background-color: #847bba;
    background-image: linear-gradient(to bottom, #847bba, #7568ba);
    border: 1px solid #493e87;
    box-shadow: inset 0 1px 0 #bab6d4, inset 0 -1px 0 #655aa1, inset 0 0 0 1px #948dba, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-blue {
    background-color: #42b0e3;
    background-image: linear-gradient(to bottom, #42b0e3, #2ba9e3);
    border: 1px solid #107db0;
    box-shadow: inset 0 1px 0 #7cd4fc, inset 0 -1px 0 #2696c9, inset 0 0 0 1px #59b7e3, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-green {
    background-color: #97cc76;
    background-image: linear-gradient(to bottom, #97cc76, #8bcc62);
    border: 1px solid #5f993a;
    box-shadow: inset 0 1px 0 #c6e5b3, inset 0 -1px 0 #79b356, inset 0 0 0 1px #a4cc8b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
</style>
</head>
<body>


<h2><?php echo $text_g; ?></h2>

<form method = "POST">
  <div class="container">
   <?php
     //������� � ��������� � �������� ���������
echo '<table class="table-3" border="2">';
     while ($row=mysqli_fetch_array($mes_all))
     { 
     $user_m= $row['user_otp']; 
     $user_p= $row['user_id']; 
     $theme_m= $row['theme']; 
   $theme_l= $row['theme_long']; 
     $status_m= $row['statuse']; 
   $ident_m= $row['id_mes']; 
     $act_m= $row['activ'];
      echo "<tr>";
         
if($act_m<>"1")
         {
          $link_act = "messages.php";
         
         echo "<td>";
         echo '
         <a href='.$link_act.'?act='.$ident_m.' class="button-grey">�������� (���������)</a>
         ';
         echo "</td>";
         }


      $link_del = "messages.php"; 
      $link_otv = "mes.php"; 
      echo "<td>"."�����������:".$user_m."<br> ����������:".$user_p."<br>ID:(".$ident_m.")</td>";
      echo "<td>";
              echo $theme_m; echo "<br>"; echo "<br>";
echo "</td>";
echo "<td>";
echo $theme_l;
echo "</td>";
 echo "<td>";

 echo ' <a href='.$link_otv.'?sm='.$ident_m.'  class="button-grey">��������</a> '; 
echo '
            <a href='.$link_del.'?arx='.$ident_m.' class="button-grey">� �����</a>
';
echo '
<a href='.$link_del.'?del='.$ident_m.' class="button-grey">�������</a>
';
      echo "</td>";
      echo "</tr>";
      
      }

     echo "</table>";
   ?>
    
  </div>

</form>


</body>
</html>



