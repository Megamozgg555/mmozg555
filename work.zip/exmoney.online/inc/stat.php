<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
    $ip=$_SERVER["REMOTE_ADDR"];
    $uri=$_SERVER["REQUEST_URI"];
    $ref=$_SERVER["HTTP_REFERER"];
    $date=time();
    $anonu= "1";
    $userhash=$_COOKIE['login'];
         if(!$userhash)
         {
         $localusr =uniqid('a_');
         $anonu = "0";
         setcookie("login", $localusr, time()+60*60*24*30, "/" , null, null, true);         /* , null, null, true */
         }
    $user = $_COOKIE['login'];
    $sql = "SELECT `id`, `user`, `user_ip`, `user_ref`, `dat` FROM `users_online` WHERE user='".$user."'";
    $res= mysqli_query($str, $sql);
  while ($row_f=mysqli_fetch_array($res))
  { 
        $res_c=$row_f[0]; 
   }
 if($res_c>0)
       {
       $sql = "UPDATE `users_online` SET dat='$date'  WHERE user='".$user."'";
       $res_upd= mysqli_query($str, $sql);
       }
      else
       {
         if(isset($user))
         {
        $sql = "INSERT INTO `users_online`(`id`, `user`, `user_ip`, `user_ref`, `dat`) VALUES ('$anonu','$user','$ip','$ref','$date')";
        $res_ins= mysqli_query($str, $sql);
         }
       }

/* ������ ������������ ������ 5 ����� ����������� */
 $sql = "DELETE FROM `users_online` WHERE dat+300 <'".$date."'";
 $result_clea= mysqli_query($str, $sql);

/* ������� ���������� ���� ��������� */
$sql = "SELECT `id`, `user`, `user_ip`, `user_ref`, `dat` FROM `users_online` WHERE 1";
$result= mysqli_query($str, $sql);
echo " <font color ='white'>������������ ������: </font>";
while ($rst=mysqli_fetch_array($result))
  { 
    echo " <font color ='black'> ";
    echo $rst[1]."  ,  ";
    echo " </font> ";
  }

mysqli_close($str);
?>
   
