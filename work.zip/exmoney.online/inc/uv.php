<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
</head>
<body>


         <div class= "alert" style="position:fixed; top:1%; right:1%">
         <span class= "closebtn" onclick= "this.parentElement.style.display= 'none' ;">x</span>
         <strong><?php echo $text_t_uv; ?></strong>
         <?php echo $text_s_uv; ?>
          </div>
          
</body>
</html>



