<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");

if(isset($_POST['submit'])) 
{ 
        include ('../gb_connect.php');
        $text_sql = $_POST['text_sql'];
                   
        $qeryl = $text_sql;
        $result = mysqli_query($str, $qeryl);       
        

while ($row=mysqli_fetch_array($result))
{ 
$pole1=$row[0]; 
$pole2=$row[1]; 
$pole3=$row[2]; 
echo "<table>";
echo "<tr>";
echo "<td>".$pole1."</td>";
echo "<td>".$pole2."</td>";
echo "<td>".$pole3."</td>";
echo "<td>".$pole4."</td>";
echo "<td>".$pole5."</td>";

echo "</tr>";
echo "</table>";
}
//mysql_free_result($result);
        mysqli_close($str);
}
?>

<html>
 <head>
 <title>������ </title> 
<meta name="viewport" content="width=device-width, user-scalable=yes">
<meta http-equiv="Content-Type" content="text/html; charset=cp1251">
<style>
body
{
background-color: #FFFFF0;
}
 .text 
{
 text-align: center;
color:#191970;
font-size:25px;
 } 
 .cena
{
 text-align: left;
color:#2F4F4F;
font-size:20px;
 } 
 .oplata
{
 text-align: left;
color:#8B4513;
font-size:17px;
 } 
</style>
</head>
 <body> 

 <form method="POST" position = "center"> <br>
<fieldset> 
<?php
echo "<a href='../AP/load.php'> <div class = 'text'> ������� </div>  </a>";
?>
<input name="submit" type="submit" class = 'text' value="��������"> 
<textarea name="text_sql" cols="30" rows="15" wrap="soft | hard" style="font-family: tahoma; font-size: 20px;"  required ></textarea>
   
</form>

</body>
 </html>
