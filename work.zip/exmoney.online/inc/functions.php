<?php
$fn_user = $_COOKIE['login'];

//�������� �������� �����
function lic_scet()
{
include ('gb_connect.php');
global $fn_user;
$sql_f = "
SELECT
( 
(SELECT SUM(`sum_dv`) AS `sum_p` FROM `bg_finance` WHERE vid_dv='+' AND user_id='".$fn_user."') 
-
(SELECT SUM(`sum_dv`) AS `sum_r` FROM `bg_finance` WHERE vid_dv='-' AND user_id='".$fn_user."')
 ) AS `s_ostatok` ";
$result_f = mysqli_query($str, $sql_f);      
        while ($row_f=mysqli_fetch_array($result_f))
        { 
        $res_bl=$row_f[0]; 
        return $res_bl;
        }

mysqli_close($str);
}

function showmess($id_m)
{
$sql = "SELECT * FROM `messages` WHERE id_mes ='".$id_m."'";
include($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
$sel_res= mysqli_query($str, $sql);
return $sel_res;
mysqli_close($str);
}

function sent_m($arr_f)
{
global $fn_user;
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
$sql = "INSERT INTO `messages`(`user_id`, `user_otp`, `theme`, `theme_long`, `statuse`, `th_obj`, `id_mes`) VALUES ('$arr_f[1]','$arr_f[0]','$arr_f[2]','$arr_f[3]','1','private','$arr_f[4]')";
$result_f = mysqli_query($str, $sql);      
mysqli_close($str);
}

function select_m($pg)
{
global $fn_user;
$sql = "SELECT *  FROM `messages` WHERE statuse<> '3' AND  user_id='".$fn_user."'";
if($pg == "1")
{
$sql = "SELECT *  FROM `messages` WHERE statuse<> '3' AND  user_id='".$fn_user."'";
}
if($pg == "2")
{
$sql = "SELECT *  FROM `messages` WHERE statuse<> '3' AND  user_otp='".$fn_user."'";
}
if($pg == "3")
{
 

$sql = "

        SELECT *  FROM `messages` WHERE statuse= '3' AND   user_id='".$fn_user."'
        UNION
        SELECT *  FROM `messages` WHERE statuse= '3' AND   user_otp='".$fn_user."'
 ";


}
include ('../gb_connect.php');
$sel_res= mysqli_query($str, $sql);
return $sel_res;
mysqli_close($str);
}

function count_m()
{
global $fn_user;
$sql = "SELECT * FROM `messages` WHERE activ<> '1' AND statuse= '1' AND user_id='".$fn_user."'";
include ('gb_connect.php');
$sel_m= mysqli_query($str, $sql);
$count_m = mysqli_num_rows($sel_m);
return $count_m;
mysqli_close($str);
}

function del_m($id_m)
{
$sql = "DELETE FROM `messages` WHERE id_mes ='".$id_m."'";
include ('../gb_connect.php');
$sel_m= mysqli_query($str, $sql);
mysqli_close($str);
}

function tarif_user($user_t)
{
$sql = "SELECT * FROM `bg_users_tarifes` WHERE  id_user='".$user_t."'";
include ('gb_connect.php');
$sel_t= mysqli_query($str, $sql);
$count_t = mysqli_num_rows($sel_t);
return $count_t;
mysqli_close($str);
}

function select_tarifs($user_t)
{
$sql = "SELECT * FROM `bg_users_tarifes` WHERE  id_user='".$user_t."'";
include ('../gb_connect.php');
$sel_res= mysqli_query($str, $sql);
return $sel_res;
mysqli_close($str);
}

function arhiv_m($id_m)
{
$st_arh= "3";
$sql = "UPDATE  `messages` SET statuse= '$st_arh' WHERE  id_mes ='".$id_m."'";
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
$sel_m= mysqli_query($str, $sql);
mysqli_close($str);
}
function activ_m($id_m)
{
$st_act= "1";
$sql = "UPDATE  `messages` SET activ= '$st_act' WHERE  id_mes ='".$id_m."'";
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
$sel_m= mysqli_query($str, $sql);
mysqli_close($str);
}
function dostup($f_user)
{
    $sas = "0";
    $sql = "SELECT * FROM `bg_users_tarifes` WHERE  id_user='".$f_user."'";
     include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
     $sel_res= mysqli_query($str, $sql);
   while ($row_t=mysqli_fetch_array($sel_res))
        { 
        $sas=$row_t['id_action']; 
        }
  mysqli_close($str);

   
     if ($_COOKIE['sa'] === "1")
     {
        $sas = "3";
     } 

return $sas;
}

function stat_add()
{
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
    $ip=$_SERVER["REMOTE_ADDR"];
    $uri=$_SERVER["REQUEST_URI"];
    $ref=$_SERVER["HTTP_REFERER"];
    $date=time();
    $anonu= "1";
    $userhash=$_COOKIE['login'];
         if(!$userhash)
         {
         $localusr =uniqid('a_');
         $anonu = "0";
         setcookie("login", $localusr, time()+60*60*24*30, "/" , null, null, true);         /* , null, null, true */
         }
    $user = $_COOKIE['login'];
    $sql = "SELECT `id`, `user`, `user_ip`, `user_ref`, `dat` FROM `users_stat` WHERE user='".$user."'";
    $res= mysqli_query($str, $sql);
  while ($row_f=mysqli_fetch_array($res))
  { 
        $res_c=$row_f[0]; 
   }
 if($res_c>0)
       {
       $sql = "UPDATE `users_stat` SET dat='$date'  WHERE user='".$user."'";
       $res_upd= mysqli_query($str, $sql);
       }
      else
       {
         if(isset($user))
         {
        $sql = "INSERT INTO `users_stat`(`id`, `user`, `user_ip`, `user_ref`, `dat`) VALUES ('$anonu','$user','$ip','$ref','$date')";
        $res_ins= mysqli_query($str, $sql);
         }
       }


mysqli_close($str);
}

function reserv_s($id_osn,$sump)
{
              $balance= lic_scet();
              
                   include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
                   $id = uniqid('res_');
                   $date_pl = date();
                   $user_id = $_COOKIE['login'];
                   $user_pl = $user_id;
                   $sum_pl = $sump;
                   $osn_pl = $id_osn;
                   $psystem = "rsystem";
                   $vid_dv="-";
       if($balance>$sum_pl)
       {
           if (isset($sum_pl) )
              { 
                  $qeryl = "INSERT INTO `bg_finance`(`id`, `user_id`, `vid_dv`, `sum_dv`, `date_dv`, `osnovanie`, `platsystem`) VALUES ('$id','$user_id','$vid_dv','$sum_pl', '$date_pl','$osn_pl','$psystem')";
                  $sql = mysqli_query($str, $qeryl);
              }
        }
        else
        {
          /* �������� ��� �� ������� ������� */
        echo "
                   <script>
                        alert('� ��� �� ������� ������� �� ������� �������� �����! ��������� ������ � ���������� �����.');
                   </script>
                  ";
         return "no";
        }
     mysqli_close($str);
}

function selectreserv($id_obj)
{
$user_id = $_COOKIE['login'];
$resobj = false;
include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
$sql = "SELECT * FROM `bg_finance` WHERE vid_dv='-' AND osnovanie='".$id_obj."'";

$sqlresult = mysqli_query($str, $sql);
$count_res = mysqli_num_rows($sqlresult);
     if($count_res>0)
        {
         $resobj = true;
        }
return $resobj;
mysqli_close($str);
}
?>