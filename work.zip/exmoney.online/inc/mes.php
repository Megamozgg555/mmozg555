﻿<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
include('functions.php'); 
$linkretrn ="../load.php";
$text_osn = $_POST['osn'];
$text_otpr = $_COOKIE['login'];
$text_pol = $_POST['user_pl'];
$text_theme =iconv('utf-8', 'cp1251',$_POST['theme']);
$text_mess= iconv('utf8', 'cp1251',$_POST['theme_long']);
$m_ident =$_POST['mes_id'];
$id_m=  uniqid('mes_');

if(isset($_POST['tarif_s'])) 
{ 
$text_osn ="Подключение тарифа STANDARD 150 RUR";
$text_pol = "admin";
$text_theme = "Подключение тарифа (Запрос)";
$text_mess = "Прошу подключить тариф STANDARD на (   ) месяц(ев)";
$linkretrn ="../load.php";
}
if(isset($_POST['tarif_p'])) 
{ 
$text_osn ="Подключение тарифа PROF 300 RUR";
$text_pol = "admin";
$text_theme = "Подключение тарифа (Запрос)";
$text_mess = "Прошу подключить тариф PROF на (   ) месяц(ев)";
$linkretrn ="../load.php";
}
if(isset($_POST['tarif_e'])) 
{ 
$text_osn ="Подключение тарифа EXPERT 450 RUR";
$text_pol = "admin";
$text_theme = "Подключение тарифа (Запрос)";
$text_mess = "Прошу подключить тариф EXPERT на (   ) месяц(ев)";
$linkretrn ="../load.php";
}
if(isset($_GET['ann']))
{
$text_pol = "admin";
$text_theme = "Отдел по работе с пользователями";
$text_osn ="Не авторизованный пользователь";
$linkretrn ="../load.php";
}

if(isset($_POST['send_m'])) 
{ 

$arr = [$text_otpr, $text_pol,$text_theme,$text_mess,$m_ident]; 

$mes_all= sent_m($arr); 
echo("<script>location.href='".$linkretrn."'</script>");
}
if(isset($_GET['sm'])) 
{  


$id_m_old = $_GET['sm'];
$resultf= showmess($id_m_old); 
while($row=mysqli_fetch_array($resultf))
     { 
  
     $text_pol = $row['user_otp'];
     $text_theme = "Re:".iconv('cp1251', 'utf-8',$row['theme']);
     $text_mess = iconv('cp1251', 'utf-8',$row['theme_long'])."/------------------------/";
     $text_osn = $id_m_old;
     }

}

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=cp1251">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
textarea 
{ 
width: 100%; 
box-sizing: border-box; 
}
</style>
</head>
<body>

<h2>Сообщение</h2>

<form method = "POST">
  <div class="container">
   <label for="uname"><b>ID</b></label>
    <input type="text" placeholder="Идентификатор" name="mes_id" value ="<?php echo $id_m;?>" required>

   <label for="uname"><b>Отправитель</b></label>
    <input type="text" placeholder="От кого" name="user_id" value ="<?php echo $text_otpr;?>" required>

    <label for="uname"><b>Получатель</b></label>
    <input type="text" placeholder="Кому" name="user_pl" value ="<?php echo $text_pol;?>" required>

    <label for="uname"><b>Тема</b></label>
    <input type="text" placeholder="Тема вашего сообщения" name="theme" value ="<?php echo $text_theme;?>" required>

    <label for="uname"><b>Сообщение</b></label>
    <textarea name="theme_long" placeholder="Здесь должно быть  ваше сообщение!" cols="auto" rows="7" wrap="soft | hard" style="font-family: tahoma; font-size: 20px;"  required ><?php echo $text_mess;?></textarea>

<label for="psw"><b>Основание</b></label>
    <input type="text" placeholder="" name="osn" value ="<?php echo $text_osn;?>"  required>

    <label for="psw"><b>Дата/время возникшей ситуации <br> (не обязательно)</b></label>
    <input type="datetime-local" placeholder="" name="date_s" >
        <br><br>
    <button type="submit" name = "send_m">Отправить</button>
    
  </div>

</form>

<form action= "<?php echo $linkretrn; ?>">
<div class="container" style="background-color:#f1f1f1">
    <button type="submit" name = "closef" class="cancelbtn">Отмена</button>
    <span class="psw"> <a href="">Справка</a></span>
  </div>
</form>


</body>
</html>



