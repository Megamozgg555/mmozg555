<?php

$host = 'localhost'; 
$database = 'u1702428_default';
$user = 'u1702428_default';
$password = '6xRT3VQe02utk3MG';
$db_table_to_show = 'users';

$str= mysqli_connect($host, $user,$password , $database);
mysqli_set_charset($str, 'utf8');

?>