﻿<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
     
     
include ('menu.php');
  

?>



<!DOCTYPE html>
<html>
<head>

<style>
body 
{
font-family: Arial, Helvetica, sans-serif;
background-color: #FFFFF0;
background: black;
background-image: url(img/f.jpg);
}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
}
textarea 
{ 
width: 100%; 
box-sizing: border-box; 
}
select
{
color: black;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    font-size: 25px;
    text-align: center;
    margin-top: 0px;
    width: 90%;
}
a {
    background-image: linear-gradient(lightgray, skygray);
    border: 1px solid #eee;
    border-radius: 8px;
    color: grey;
    display: inline-block;
    line-height: 32px;
    padding: 0 15px;
    text-decoration: none;
    transition: none;
    vertical-align: top;
}
a:hover {
  box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2;  
}
.button-grey {
    background-color: #f2f2f2;
    background-image: linear-gradient(to bottom, #f2f2f2, #f2f2f2);
    border: 1px solid #bfbfbf;
    box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #8c8c8c;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
    
}
.button-yellow {
    background-color: #fce374;
    background-image: linear-gradient(to bottom, #fce374, #fcdf5b);
    border: 1px solid #c9ae34;
    box-shadow: inset 0 1px 0 #fff6ce, inset 0 -1px 0 #e3c852, inset 0 0 0 1px #fce88d, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #967d09;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}
.button-orange {
    background-color: #f58a38;
    background-image: linear-gradient(to bottom, #f58a38, #f57c20);
    border: 1px solid #c25706;
    box-shadow: inset 0 1px 0 #ffb984, inset 0 -1px 0 #db6f1d, inset 0 0 0 1px #f59851, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-red {
    background-color: red;
    font-size: 25px;
    border: 1px solid #ba3329;
    box-shadow: inset 0 1px 0 #ffb0aa, inset 0 -1px 0 #d44d44, inset 0 0 0 1px #ed837b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    margin-top: 0px;
    width: 90%;
  
}
.button-purple {
    background-color: #847bba;
    background-image: linear-gradient(to bottom, #847bba, #7568ba);
    border: 1px solid #493e87;
    box-shadow: inset 0 1px 0 #bab6d4, inset 0 -1px 0 #655aa1, inset 0 0 0 1px #948dba, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-blue {
    background-color: #42b0e3;
    background-image: linear-gradient(to bottom, #42b0e3, #2ba9e3);
    border: 1px solid #107db0;
    box-shadow: inset 0 1px 0 #7cd4fc, inset 0 -1px 0 #2696c9, inset 0 0 0 1px #59b7e3, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-green {
    background-color: #97cc76;
    background-image: linear-gradient(to bottom, #97cc76, #8bcc62);
    border: 1px solid #5f993a;
    box-shadow: inset 0 1px 0 #c6e5b3, inset 0 -1px 0 #79b356, inset 0 0 0 1px #a4cc8b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.texta {
    
    
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    font-size: 25px;
}
.textb {
    
    
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    font-size: 20px;
}
.table {
	width: 100%;
	margin-bottom: 20px;
	border: 1px solid #dddddd;
	border-collapse: collapse; 
}
.table th {
	font-weight: bold;
	padding: 5px;
	background: #efefef;
  background-color: #f8f8f8; 
  border: 1px solid #dddddd;
color: #013220;
}
.table td {
	border: 1px solid #dddddd;
	padding: 5px;
   color: #037d50;
  
}
</style>
</head>
<body>
<br>
 <div class="texta">
           Selected products
     </div>
<br>
 <div class="textb">
           


     </div>
<br><br>
      
     <br>
              <div class="texta">
    <?php
            include ('gb_connect.php');
            $order_id = $_COOKIE['or'];
            $sql = "SELECT `id`, `id_order`, `product`, `price`, `count`    FROM cart WHERE id_order=".$order_id; 
            $res=mysqli_query($str,$sql); 
echo  '   <table class="table" > 
                <thead>
		<tr>
			<th>ID</th>
			<th>Product</th>
			<th>Price</th>
			<th>Count</th>
        
		</tr>
	</thead>';
$c_summ= 0;
                    while ($row=mysqli_fetch_array($res))
                    { 
                         $c_id=$row[0]; 
                         $c_order=$row[1]; 
                         $c_product=$row[2]; 
                         $c_price=$row[3]; 
$c_summ = $c_summ+$c_price;
                         $c_count=$row[4]; 
                         $link_k ="auction/c_del.php";
                         $c_del =    '<a href='.$link_k.'?ipr='.$c_id.'&ord='.$c_order.' >❌</a>';;

echo '
                         <tbody> 
                           <tr>
                           
                              <td>'.$c_id.'</td>                          
                              <td>'.$c_product.'</td>
                              <td>'.$c_price.'</td>
                              <td>'.$c_del.'</td>
                              
                           </tr>
                           
                         </tbody> 
          
		
	</thead>
                          
               
        ';
                     }
echo '</table>';

echo " Summ: ".$c_summ." $";
                    mysqli_close($str);

                   ?>
<br><br>
                      <label >country:</label><br>
         <select name="s1"> 
                  <option value="1">Russia</option> 
                  <option value="2">USA</option>
                  <option value="3">Germany</option> 
                  <option value="4">Ukraine</option>
                  <option value="5">Brazil</option>
         </select> <br><br>
               <form action="pay.php?ord=<?php echo $order_id."&s=".$c_summ;?>" method="POST"   > 
                      email: <input type="text" name="nid"  value ="" required> <br>    <p></p>  
                      Telegram: <input type="text" name="nid2"  value ="" required> <br>    <p></p>      
                      Nearest city,locality: <input type="text" name="nid3"  value ="" required> <br>    <p></p>
                      <p><input type="submit" class = 'button-red' value="PAY"></p>
                
              </form>
              </div>
<br>
</body>
</html>



