<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
setcookie("login", "", time() - 3600*24*30*12, "/"); 
header("Location: index.php"); 
exit; 
?> 

