﻿<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");
     include ('gmenu.php');

?>



<!DOCTYPE html>
<html>
<head>

<style>
body 
{
font-family: Arial, Helvetica, sans-serif;
background-color: #FFFFF0;
background: black;
background-image: url(img/f.jpg);
}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
}
textarea 
{ 
width: 100%; 
box-sizing: border-box; 
}

a {
    background-image: linear-gradient(lightgray, skygray);
    border: 1px solid #eee;
    border-radius: 8px;
    color: grey;
    display: inline-block;
    line-height: 32px;
    padding: 0 15px;
    text-decoration: none;
    transition: none;
    vertical-align: top;
}
a:hover {
  box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2;  
}
.button-grey {
    background-color: #f2f2f2;
    background-image: linear-gradient(to bottom, #f2f2f2, #f2f2f2);
    border: 1px solid #bfbfbf;
    box-shadow: inset 0 1px 0 white, inset 0 -1px 0 #d9d9d9, inset 0 0 0 1px #f2f2f2, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #8c8c8c;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
    
}
.button-yellow {
    background-color: #fce374;
    background-image: linear-gradient(to bottom, #fce374, #fcdf5b);
    border: 1px solid #c9ae34;
    box-shadow: inset 0 1px 0 #fff6ce, inset 0 -1px 0 #e3c852, inset 0 0 0 1px #fce88d, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #967d09;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}
.button-orange {
    background-color: #f58a38;
    background-image: linear-gradient(to bottom, #f58a38, #f57c20);
    border: 1px solid #c25706;
    box-shadow: inset 0 1px 0 #ffb984, inset 0 -1px 0 #db6f1d, inset 0 0 0 1px #f59851, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-red {
    background-color: red;
    
    border: 1px solid #ba3329;
    box-shadow: inset 0 1px 0 #ffb0aa, inset 0 -1px 0 #d44d44, inset 0 0 0 1px #ed837b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    margin-top: 0px;
    width: 90%;
  
}
.button-purple {
    background-color: #847bba;
    background-image: linear-gradient(to bottom, #847bba, #7568ba);
    border: 1px solid #493e87;
    box-shadow: inset 0 1px 0 #bab6d4, inset 0 -1px 0 #655aa1, inset 0 0 0 1px #948dba, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-blue {
    background-color: #42b0e3;
    background-image: linear-gradient(to bottom, #42b0e3, #2ba9e3);
    border: 1px solid #107db0;
    box-shadow: inset 0 1px 0 #7cd4fc, inset 0 -1px 0 #2696c9, inset 0 0 0 1px #59b7e3, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.button-green {
    background-color: #97cc76;
    background-image: linear-gradient(to bottom, #97cc76, #8bcc62);
    border: 1px solid #5f993a;
    box-shadow: inset 0 1px 0 #c6e5b3, inset 0 -1px 0 #79b356, inset 0 0 0 1px #a4cc8b, 0 2px 4px rgba(0, 0, 0, 0.2);
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
.texta {
    
    
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    font-size: 25px;
}
.textb {
    
    
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
    text-align: center;
    font-size: 20px;
}
.table {
	width: 100%;
	margin-bottom: 20px;
	border: 1px solid #dddddd;
	border-collapse: collapse; 
}
.table th {
	font-weight: bold;
	padding: 5px;
	background: #efefef;
  background-color: #f8f8f8; 
  border: 1px solid #dddddd;
color: #013220;
}
.table td {
	border: 1px solid #dddddd;
	padding: 5px;
   color: #037d50;
  
}
</style>
</head>
<body>
<br>
 <div class="texta">
           Payment
     </div>
<br>
 <div class="textb">
           Payment amount<br>
           ORDER √<?php echo $_GET['ord']; ?><br>
           <br>
          <div class="texta">
          <font color ='#037d50'> 
           <?php 
           $sumd = $_GET['s'];
      //     $data = file_get_contents("https://apirone.com/api/v1/tobtc?currency=usd&value=".$sumd.""); 
           
                  echo $data." BTC"; 
           ?><br>
          </font>
           
           <font color ='red' size ='2px'> 
           <?php 
                  $file_patch ="img/qr.png";

                  echo '<td><img  src="'.$file_patch.'"  width="50%" ></td>'; 	

                   echo "bc1q8c09c2ty5m4730ktdgcycfkerkzdj552kjc2j5"; 

           ?>
          </font>


         </div>
     </div>
<br><br>
      
     <br>
              <div class="texta">
                     The operator will send you the<br>
                      coordinates of the treasure. 
                      Remember your order number <br>
                      and payment screenshot<br><br>
                       <a href="https://t.me/darkmarketvi" class="button-red"><font color ='white'> Telegram(Support)</font></a>

                       <a href="mailto:gbhk2025@protonmail.com" class="button-red"><font color ='white'> Mail:(sales)</font></a>
                       <br><br>
                       <a href="bay.php" class="button-red"><font color ='white'> Close</font></a>
              </div>
<br>
</body>
</html>



