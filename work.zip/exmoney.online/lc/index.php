<?php
header('Content-Type: text/html; charset= utf8');
mb_internal_encoding("utf8");
 
     include ('menuap.php');
     include ('op.php');
    include ('../inc/functions.php'); 
?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style_tb.css" type="text/css"  />
<style>
body 
{
font-family: Arial, Helvetica, sans-serif;
background-color: #FFFFF0;
background: white;
}
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>
<?php

?>
</body>
</html>



