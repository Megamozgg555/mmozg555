<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, user-scalable=yes">
<style>
* {
    box-sizing: border-box;
}

input[type=text], select, textarea, number {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
}

label {
    padding: 12px 12px 12px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
width: 100%;
}
input[type=number] {
    background-color: gray;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
width: 100%;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
width: 100%;
}

.col-25 {
    float: left;
    width: 100%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 100%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body>

<?php
      $pole1=iconv("cp1251", "UTF-8", "�������:"); 
      $pole2=iconv("cp1251", "UTF-8", "����������:"); 
      $pole3=iconv("cp1251", "UTF-8", "���������:"); 
      $pole4=iconv("cp1251", "UTF-8", "� ���������:"); 
      $pole5=iconv("cp1251", "UTF-8", "����� �����:"); 
$pole6=iconv("cp1251", "UTF-8", "�������� ������"); 

?>


<div class="container">
  <form method="POST">

    <div class="row"><br><br><br>
<label ><?php echo $pole1; ?></label><br>
<div class="col-25">
        <label for="fname"><?php echo $pole2; ?></label>
      </div><br><br>
<div class="col-756">
        <input type="number" id="fname" name="fname" value="0.003">
      </div>
<br><br><br>
         <select name="cat"> 
                  <option value="0">BTC Bitcoin</option> 
                  <option value="1">QIWI RUR</option>
                  
         </select> <br><br>

      
    </div>
    <div class="row">
      
<label ><?php echo $pole3; ?></label><br>
         <select name="os"> 
                  <option value="2">QIWI RUR</option>
                  <option value="1">BTC Bitcoin</option> 
                  
                  
         </select> <br><br>
      <div class="col-25">
        <label for="fname"><?php echo $pole2; ?></label>
      </div>
      <div class="col-75">
        <input type="number" id="fname" name="fname">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="price"><?php echo $pole4; ?></label>
      </div>
      <div class="col-75">
        <input type="number" id="price" name="price">
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="price"><?php echo $pole5; ?></label>
      </div>
      <div class="col-75">
        <input type="text" id="price" name="price">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="price">E-Mail</label>
      </div>
      <div class="col-75">
        <input type="text" id="price" name="price">
      </div>
    </div>
    <br>

    <div class="row">
      <input type="submit" name = "submit" value="<?php echo $pole6; ?>"> <br><br><br>
      
    </div>
  </form>
</div>

</body>
</html>
