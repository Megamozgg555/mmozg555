<?php

$host = 'localhost'; 
$database = 'u1676003_default';
$user = 'u1676003_default';
$password = 'QJ0Wc55na9VmKe5F';
$db_table_to_show = 'users';

$str= mysqli_connect($host, $user,$password , $database);
mysqli_set_charset($str, 'utf8');


?>

