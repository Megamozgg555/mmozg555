<?php
function showusers(){include ('gb_connect.php');     $users = $_GET['pg'];             if (isset($users) )        {           echo '             <table id="customers">  <tr>        <th>User</th>    <th>Password</th>  </tr>             ';           $qwer = "SELECT *  FROM users WHERE 1";            $res=mysqli_query($str,$qwer);            $cfield =   mysqli_num_fields($res);                      while ($row=mysqli_fetch_array($res))           {                             $pole1=$row[0];               $pole2=$row[1];               $pole3=$row[2];               $pole4=$row[3];                      echo '            <tr>                               <td>'.$pole2.'</td>               <td>'.$pole3.'</td>            </tr>';                       }                echo '</table>';        }mysqli_close($str);}
function showproducts()
{
include ('gb_connect.php');     
$users = $_GET['pg'];      
       if (isset($users) )  
      { 
          echo '             <table id="customers"> 
           <tr>
        <th>Name</th>
         <th>Description</th>
         <th>price</th>  </tr>             ';          
             $qwer = "SELECT *  FROM products WHERE 1";
            $res=mysqli_query($str,$qwer); 
             $cfield =   mysqli_num_fields($res);
                      while ($row=mysqli_fetch_array($res))  
                      { 
                            $pole1=$row[0];  
                             $pole2=$row[1]; 
                             $pole3=$row[2]; 
                            $pole4=$row[3];  
                        echo '
                        <tr>    
                           <td>'.$pole2.'</td> 
                            <td>'.$pole3.'</td>  
                            <td>'.$pole4.'</td>  
                        </tr>'; 
                      }   
             echo '</table>';     
   }
mysqli_close($str);
}
function product($idp){include ('gb_connect.php');           $qwer = "SELECT *  FROM products WHERE id=".$idp;            $res=mysqli_query($str,$qwer);            return $res;           mysqli_close($str);}
?>