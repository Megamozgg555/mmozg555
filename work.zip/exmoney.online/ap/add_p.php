<?php
header('Content-Type: text/html; charset= cp1251');
mb_internal_encoding("cp1251");

if(isset($_POST['closef']))
{
header("Location: index.php"); 
}

if(isset($_POST['submit']))
{
include ('../gb_connect.php');
      
     $p_id =uniqid('p_');
     $nam =iconv("cp1251", "UTF-8", $_POST['fname']); 
     $cat =iconv("cp1251", "UTF-8", $_POST['cat']); 
     $os =iconv("cp1251", "UTF-8", $_POST['os']); 
     $price = $_POST['price'];
     $nam_long = iconv("cp1251", "UTF-8",$_POST['fname_long']);
     
$qeryl = "INSERT INTO `products`(`id`, `name`, `name_long`, `price`,`category`,`os`) VALUES ('$p_id','$nam','$nam_long','$price','$cat','$os')";
$sql = mysqli_query($str, $qeryl);

mysqli_close($str);
header("Location: index.php"); 
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, user-scalable=yes">
<style>
* {
    box-sizing: border-box;
}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
}

label {
    padding: 12px 12px 12px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body>

<h2>����� �������</h2>
<p>���������� ��������� ��� ����!</p>


<div class="container">
  <form method="POST">

    <div class="row">
<label >�������� ���������:</label><br>
         <select name="cat"> 
                  <option value="0">VDS ������</option> 
                  <option value="1">VPS ������</option>
                  <option value="2">Proxy Server</option> 
                  <option value="3">�������� FS</option>
                  <option value="4">Mail Server</option>
                  <option value="5">��������� ������</option>
                  
         </select> <br><br>
<label >�������� ��:</label><br>
         <select name="os"> 
                  <option value="1">Linux</option> 
                  <option value="2">Windows</option>
                  
         </select> <br><br>
      <div class="col-25">
        <label for="fname">������������</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="fname">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="price">���� $</label>
      </div>
      <div class="col-75">
        <input type="number" id="price" name="price">
      </div>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label for="fname_long">��������</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="fname_long"  style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" name = "submit" value="���������">
      <input type="submit" name = "closef" value="������">
    </div>
  </form>
</div>

</body>
</html>
