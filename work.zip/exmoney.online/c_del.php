<?php

$product_id = $_GET['ipr'];
$order_id = $_GET['ord'];

if(isset($order_id))
{
    $sql = "DELETE FROM  `cart`  WHERE  id_order ='".$order_id."' AND id = '".$product_id."'  ";
    include ($_SERVER['DOCUMENT_ROOT'].'/gb_connect.php');
    $sel_m= mysqli_query($str, $sql);
    mysqli_close($str);
    echo("<script>location.href='../bay.php'</script>"); 
}

?>
