
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
    box-sizing: border-box;
}

.columns {
    float: left;
    width: 33.3%;
    padding: 8px;
}

.price {
    list-style-type: none;
    border: 1px solid #eee;
    margin: 0;
    padding: 0;
    -webkit-transition: 0.3s;
    transition: 0.3s;
}

.price:hover {
    box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}

.price .header {
    background-color: #111;
    color: white;
    font-size: 25px;
}

.price li {
    border-bottom: 1px solid #eee;
    padding: 20px;
    text-align: center;
}

.price .grey {
    background-color: #eee;
    font-size: 20px;
}

.price .while {
    background-color: while;
    font-size: 20px;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 25px;
    text-align: center;
    text-decoration: none;
    font-size: 18px;
}

@media only screen and (max-width: 600px) {
    .columns {
        width: 100%;
    }
}
</style>
</head>
<body>

<h2 style="text-align:center">Responsive Pricing Tables</h2>



<?php

include ('gb_connect.php');

$qwer = "SELECT *  FROM products WHERE 1"; 
           $res=mysqli_query($str,$qwer); 
                     
           while ($row=mysqli_fetch_array($res))
           { 
              
              $pole1=$row[0]; 
              $pole2=$row[1]; 
              $pole3=$row[2]; 
              $pole4=$row[3]; 
           
          echo '
             <div class="columns">
             <ul class="price">
             <li class="header" style="background-color:#4CAF50">'.$pole2.'</li>
             <li>'.$pole3.'</li>    
             <li>100% Anonymous Service</li>
             <li>Support 24H</li>
             <li class="grey">'.$pole4.' $ / Month</li>';
         if(isset($_COOKIE['login']))
          {
        echo '     <li class="while"><a href="#" class="button">Buy</a></li>';
       echo '
           <a href='.$link_k.'?ipr='.$row[0].'&ord='.$_COOKIE['or'].' class="button-red">Bay</a>
         ';
          }
         else
         {
          echo '     <li class="while"><a href="login.php" class="button">Buy</a></li>';
         }
       echo '      </ul>
             </div>
                  ';
            
           }
        
        
mysqli_close($str);



?>
  


</body>
</html>



