<?php
include ('../gb_connect.php');
$product_id = $_GET['ipr'];
$sql = "SELECT `lot`, `user_id`,`name`, `name_long`, `budget`, `tek_cena`, `status`, `lot_date_end`    FROM bg_auction WHERE lot=".$product_id; 
$res=mysqli_query($str,$sql); 

while ($row=mysqli_fetch_array($res))
{ 
$product=$row[2]; 
$price=$row[4]; 

}
/*
mysqli_close($str);
*/
     
   $order_id = $_GET['ord'];
   $p_count = "1";
   
if (isset($order_id) )
{ 
$qeryl = "INSERT INTO `cart`(`id`, `id_order`, `product`, `price`, `count`) VALUES ('$product_id','$order_id','$product','$price','$p_count')";
$sql = mysqli_query($str, $qeryl);
}
mysqli_close($str);

echo("<script>location.href='../bay.php'</script>");

?>

