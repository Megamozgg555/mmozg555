//Namespace.provide('App');
//Namespace.provide('App.Util');
//Namespace.provide('App.Captcha');

/**
 * @namespace App
 */
Namespace('App', class App {
    /**
     * @static
     * @private
     * @type {*}
     */
    static registry = new Map();
    /**
     * @static
     * @private
     * @type {*}
     */
    static libs = new Map();

    /**
     * @static
     * @return {Object.<string, mixed>|String|Array}
     */
    static get data() {
        return this.registry.get('appData');
    }

    /**
     * @static
     * @param {*} data
     * @return {Map}
     */
    static set data(data) {
        return this.registry.set('appData', data);
    }

    /**
     * @static
     * @return {*}
     */
    static get vars() {
        return this.registry.get('vars');
    }

    /**
     * @static
     * @param {*} data
     * @return {Map}
     */
    static set vars(data) {
        return this.registry.set('vars', data);
    }

    /**
     * @static
     * @return {*}
     */
    static get lodash() {
        return this.libs.get('lodash');
    }

    /**
     * @static
     * @param {Object} $l   Lodash instance
     * @return {Map}
     */
    static set lodash($l) {
        return this.libs.set('lodash', $l);
    }

    // static get opts() {
    //     return this.$registry.get('opts');
    // }
    //
    // static set opts(opts) {
    //     return this.$registry.set('opts', opts);
    // }

    /**
     * @static
     * @return {Object.<string, integer>|Array}
     */
    static get counters() {
        return this.registry.get('counters');
    }

    /**
     * @static
     * @param {Object.<string, integer>|Array} data
     * @return {Map}
     */
    static set counters(data) {
        return this.registry.set('counters', data);
    }

    /**
     * @static
     * @return {boolean|integer}
     */
    static get userId() {
        if (this.data != null && this.data['userId']) {
            return this.data['userId'];
        }
        return false;
    }
});

Namespace('App.Util', class AppUtil {
    static addEventListener(...opts) {
        let [$el, $ev, $func] = opts;

        if (typeof($el) == 'object') {
            return $el.addEventListener($ev, $func);
        }

        return false;
    }

    static fireEvent(...opts) {
        let [$el, $ev, $cdata] = opts;
        let $ = App.lodash;

        if ($cdata && $.size($cdata) > 0) {
            $ev = new CustomEvent($ev, $cdata);
        } else {
            $ev = new Event($ev);
        }

        return $el.dispatchEvent($ev);
    }

    static removeEventListener(...opts) {
        let [$el, $ev, $func] = opts;
        return $el.removeEventListener($ev, $func);
    }

    static isFunction(func) {
        return typeof(func) === 'function';
    }
});

Namespace('App.XHR', class AppXHR {
    static prepare({ params = {}, json = false, html = false }) {
        let $ = App.lodash;
        let headers = {};

        $.defaults(params, {
            headers: {},
            redirect: 'follow',
            cache: 'no-cache'
        });

        let body = '';

        if(params.json) {
            //query = ($.size(query) > 0) ? JSON.stringify(query) : query;
            headers = { 'Content-Type': 'application/json' };
            body = JSON.stringify(params.body);
        } else if(params.html) {
            headers = { 'Content-Type': 'text/html' };
        } else {
            headers = { 'Content-Type': 'text/plain' };
        }

        $.defaultsDeep(params, { headers: headers });
        $.unset(params, 'json');
        $.unset(params, 'html');

        return params;
    }

    static get(uri, { params = { json: true, html: false }, success, error }) {
        let $ = App.lodash;

        params = this.prepare({ params: params });
        $.defaults(params, {
            method: 'GET'
        });

        success = App.Util.isFunction(success) ? success : (res) => { App.Util.fireEvent(window, 'xhr:success', { data: res }); };
        error   = App.Util.isFunction(error) ? error : (res) => { App.Util.fireEvent(window, 'xhr:error', { data: res }); };

        return fetch(uri, params).then(res => {
            if (res.ok) {
                if (success) success(res);
            } else {
                if (error) error(res);
            }
            return res;
        });
    }

    static getJSON(uri, { params = {}, success = false, error = false }) {
        let $ = App.lodash;
        $.defaults(params, { json: true });
        return this.get(uri, {
            params: params,
            success: success,
            error: error
        });
    }

    static post(uri, { params = {}, success = false, error = false }) {
        let $ = App.lodash;
        $.defaults(params, { json: true });
    }

    static put(uri, { params, success, error }) {

    }
});

Namespace('App.Captcha', class AppCaptcha {
    static errors = {
        'f4388ea3c2dc54c78ec145249ed13e76': 'Указаны неверные данные',
        'cc6dc88595642692077ae31263c77623': 'Логин может содержать латинские символы (a-zA-z), числа(0-9) и нижнее подчеркивание (_)',
        '2bf442052b2ceec4012a36b729e2d26a': 'Логин не может быть менее 2 символов',
        'b6d538e20a4a4a3fc5539589b36c4d6b': 'Логин не может быть более 32 символов',
        '8b6bf8b22b8a45716dec01b06d924915': 'Пароль не может быть менее 8 символов',
        '6664d1acf40eca24b4e160f6d95efd75': 'Пароль не может быть более 128 символов',
        'e9b2ff28866f0cd2eb97bec9eebb5c10': 'Пароли не совпадают',
        '66239c9b90b1e25406ada5eb28576994': 'Логин недоступен для регистрации',
        'fb54f3c5992b96d001bb16e8e92d968d': 'Магазин с таким названием уже зарегистрирован',
        '70b29c4920daf4e51e8175179027e668': 'Проверочный код указан неверно',
        '80fad2fda354455e59bfda95e080d52f': 'Истекло время жизни проверочного кода'
    };

    static load() {
        const endpoint = 'regcaptcha.php';

        return App.XHR.getJSON(endpoint, {}).then(res => {
            return res.json();
        }).catch(e => {
            console.error(e);
        });
    }

    static showErrorsIfPresents() {
        let $ = App.lodash;
        let url = new URL(document.location.href);
        let e = url.searchParams.get('e');
        let error = '';

        if ($.size(e) > 0) {
            error = this.errors[e];
            if (!error) {
                error = 'Произошла неопознанная ошибка';
            }
        }

        return Alpine.data('error', () => ({
            message: `${error}`,

            init() {
                //console.log('messages initialized');
            }
        }));
    }

    static touchMe() {
      let range = document.querySelector('.form-range');
      if (range.getAttribute('touched') != 1) {
        range.className = "form-range touchme";
      }
    }
    
    static touchMePrepare() {
      let range = document.querySelector('.form-range');
      range.setAttribute('touched', 0);
    }

    static touchMeCancel() {
      let range = document.querySelector('.form-range');
      if (range.getAttribute('touched') != 1) {
        range.setAttribute('touched', 1);
        range.className = "form-range";
      }
    }

    static calcArg(k) {
      let res = Math.abs(Math.sin(k)) / (k + 1) + 0.0001;
      return res;
    }

    static extractPath() {
        let cont = document.getElementById('captchaCont');
        let svg = cont.querySelector('svg');
        let path = svg.querySelector('path');
        App.data = {
          captcha: path.getAttribute('d')
        }
    }

    static restoreCaptcha(time) {
        const numbers = '0123456789.-';
    		let k = Number(time);
        let cont = document.getElementById('captchaCont');
        let svg = cont.querySelector('svg');
        let path = svg.querySelector('path');
        let d = App.data.captcha;
        d = d.concat(' ');
        let numstring = '';
        let char = '';
        let newpath = '';
        for (var i = 0; i < d.length; i++) {
          char = d[i];
          if (numbers.indexOf(char) >= 0) {
            numstring = numstring.concat(char);
          } else {
            if (numstring.length > 0) {
              numstring = Number(numstring);
              k += 0.001;
              var arg = this.calcArg(k);
              numstring = numstring / arg;
              numstring = Math.round(numstring * 100) / 100;
            }
            newpath = newpath.concat(numstring);
            newpath = newpath.concat(char);
            numstring = '';
          }
        }
        this.touchMeCancel();
        path.setAttribute('d', newpath);
    }

    static init(form) {
        App.Captcha.showErrorsIfPresents();
        let dataKey = form.getAttribute('x-data');
        if (dataKey) {
            return Alpine.data(dataKey, () => ({
                svgData: '',

                init() {
                    let t = this;

                    App.Captcha.load().then(r => {
                        t.svgData = r.captcha;
                        //App.Captcha.restoreCaptcha(r.time);


                        // let captcha = r.captcha;
                        // let time = r.time;



                        return r;
                    }).then((r) => {
                        App.Captcha.extractPath();
                        App.Captcha.restoreCaptcha(0.50);
                        App.Captcha.touchMePrepare();
                        setTimeout(App.Captcha.touchMe, 5000);

                    });
                }
            }));
        }
    }
});
