yum update

yum upgrade

sudo yum update httpd

sudo yum install httpd

sudo systemctl start httpd

yum install zip

yum install mc 

yum install wget 

cd /var/www

wget https://github.com/Megamozgg555/mmozg555/raw/main/work.zip

wget https://github.com/Megamozgg555/mmozg555/raw/main/sborka.zip

yum install unzip 

unzip work.zip

