<?php

if(!file_exists('./tmpcookies/')) mkdir('./tmpcookies/', 0777, true);
define('INCLUDE_CHECK',true); 
require 'crookedmirror.php';